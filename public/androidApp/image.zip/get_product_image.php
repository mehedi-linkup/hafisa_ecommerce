<?php
require_once('db.php');
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
$pId=$_POST['productId'];
mysqli_set_charset($conn,'utf8');
$sql = "SELECT otherImage from product_images where product_id = '$pId' ";
    $run = mysqli_query($conn,$sql);
    while($data = mysqli_fetch_assoc($run)){
    	$item[] = $data ;
    	$json = json_encode(array('contents'=>$item));
    }
    echo $json ;

  
?>