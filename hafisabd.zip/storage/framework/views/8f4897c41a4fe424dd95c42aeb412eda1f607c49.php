
<?php $__env->startSection('website-content'); ?>

<section class="py-3">
    <div class="container">
        <nav style="--bs-breadcrumb-divider: '';" aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
              
            </ol>
          </nav>
    </div>
</section>
<section class="py-4 category-section" >
    <div class="container-fluid">
        <div class="row">
            <?php if($recent->count() > 0): ?>
                <?php $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $discount = 0;
                $discount = $item->discount;
                $stock = $item->inventory->purchage;
                $discount_price =$item->price - $item->price*$discount/100; 
                ?>
                <div class="lg-1 col-lg-2 col-md-6 col-6 ">
                    <div class="section-item">
                        <div class="main-card-body position-relative">
                            <img src="<?php echo e(asset('uploads/product/'.$item->image)); ?>" alt="" loading="lazy">
                            <?php if($item->discount != NULL): ?>
                            <span class="discount position-absolute"><?php echo e((int)$discount); ?>%</span>
                            <?php endif; ?>
                            <div class="product-price">
                                <h6 class="text-center fw-bolder mt-2 mb-0"><?php echo e($item->name); ?></h6>
                                <?php if($item->discount >0): ?>
                                <p class="text-center"> <span class="text-danger mx-2"><?php echo e($discount_price); ?> TK</span><span class=" text-decoration-line-through"><?php echo e($item->price); ?> TK</span></p>
                                <?php else: ?> 
                                <p class="text-center fw-bold mb-1"><?php echo e($item->price); ?> TK</p>
                                <?php endif; ?>
                                
                            </div>
                            <div class="overlay-1 overlay-1<?php echo e($item->id); ?>" id="overlay-1" >
                                <?php if($stock<1): ?>
                                <div class="add-to-cart-part">
                                    <h5>Stock Out</h5>
                                </div>
                                <?php else: ?>
                                <div class="add-to-cart-part add" onclick="addToCard(<?php echo e($item->id); ?>)">
                                    <h5>Add To Shopping Card</h5>
                                </div>
                                <?php endif; ?>
                                <div class="view-btn position-absolute bottom-0 w-100 text-center details-btn">
                                    <a href="<?php echo e(route('product.details',$item->slug)); ?>" class="text-center text-dark ">Details</a>
                                </div>
                            </div>
                            <div class="overlay-2 overlay-2<?php echo e($item->id); ?>">
                                <h5 class="text-center pt-3 text-white"><?php echo e($item->price); ?> TK</h5>
                                <div class="qtyField addTocard-2">
                                    <span class="p-m qtyBtn minus add"><i class="fas fa-minus"></i></span> 
                                    <input type="hidden" value="<?php echo e($item->id); ?>" id="id" name="id" class="id">
                                    <span><input type="text" id="Quantity" name="quantity" value="1" class="product-form__input qty"></span>
                                    <span class="p-m qtyBtn plus add"> <i class="fas fa-plus"></i></span>
                                </div>
                            </div>
                        
                        </div>
                        <?php if($stock<1): ?>
                        <div class="d-flex mb-3">
                            <a  href="javascript:void(0);" class="btn-details1 w-100" >Stock Out</a>
                        </div>
                        <?php else: ?>
                        <div class="d-flex mb-3">
                            <a  href="javascript:void(0);" class="btn-details1 w-100 add" onclick="addToCard(<?php echo e($item->id); ?>)">Add To Cart</a>
                        </div>
                        <?php endif; ?>
                    
                    </div>
                    
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            <?php else: ?>
            <h2 class="text-danger text-center">Sorry! This category product has no available</h2>
            <?php endif; ?>
            <div class="category-pagination d-flex">
                <?php echo e($recent->links()); ?>

            </div>
            
        </div>
    </div>
</section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dewbxcak/zeneviaexpress.com/resources/views/website/allProduct.blade.php ENDPATH**/ ?>