
<?php $__env->startSection('website-content'); ?>

<section class="py-5">
    <h2 class="text-center text-success"> Customer Login</h2>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6 col-12">
                
                <div class="card">
                    <div class="card-body p-3">
                      <form action="<?php echo e(route('customer.auth')); ?>" method="post">
                          <?php echo csrf_field(); ?>
                        <div class="form-group py-3">
                            <input type="text" name="userphone" class="form-control px-3" placeholder="Phone Number">
                        </div>
                        <div class="form-group py-3 position-relative">
                            <input type="password" name="password" id="id_password" class="form-control px-3 " placeholder="Password" ><i class="far fa-eye show-icon position-absolute" id="togglePassword" style="margin-left: -30px; cursor: pointer;"></i>
                        </div>
                        <div class="form-group py-3 d-flex">
                            <span>
                                <button type="submit" class="btn btn-success ">Login</button>
                            </span>
                          
                            <a href="<?php echo e(route('customer.signup')); ?>" class="btn btn-success ms-auto"> Sign Up</a>
                           </span>
                           
                        </div>
                        <div class="forget-password">
                           <a href="<?php echo e(route('forget.password')); ?>" class="text-danger">Forget Password</a>
                        </div>
                    </form>
                    </div>
                  </div>
            </div>

        </div>
    </div>
</section>
<?php
Session::forget('phone')
?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('website-js'); ?>
    <script>
         const togglePassword = document.querySelector('#togglePassword');
  const password = document.querySelector('#id_password');
 
  togglePassword.addEventListener('click', function (e) {
    // toggle the type attribute
    const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
    password.setAttribute('type', type);
    // toggle the eye slash icon
    this.classList.toggle('fa-eye-slash');
});
    </script>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\androidApp (6)\resources\views/website/customer/login.blade.php ENDPATH**/ ?>