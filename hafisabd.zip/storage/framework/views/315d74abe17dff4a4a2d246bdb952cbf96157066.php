
<?php $__env->startSection('website-content'); ?>

<section class="py-3">
    <h2 class="text-center text-success"> Customer Sign-Up</h2>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6 col-12">
 
                <div class="card px-5 py-3">
                    <?php if(count($errors) > 0): ?>
                    <div class="p-1">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-warning alert-danger fade show" role="alert"><?php echo e($error); ?> <button type="button" class="close"
                                data-dismiss="alert" aria-label="Close">
                               
                            </button></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                    <div class="card-body p-2">
                      <form action="<?php echo e(route('customerStore')); ?>" method="post">
                          <?php echo csrf_field(); ?>
                        <div class="form-group p-1">
                            <label for="">Name</label>
                            <input type="text" name="name" class="form-control px-3" placeholder="Enter Name *">
                        </div>
                        <div class="form-group p-1">
                            <label for="">Phone Number</label>
                            <input type="number" name="phone" class="form-control px-3" placeholder="Phone Number *">
                        </div>
                        
                        <div class="form-group p-1">
                            <label for="">Password</label>
                            <input type="password" name="password" class="form-control px-3" placeholder="Password">
                        </div>
                        <div class="form-group p-1">
                            <label for="">District</label>
                            <select name="district_id" id="district_id" class="form-control px-3">
                                <?php $__currentLoopData = $district; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group p-1">
                            <label for="">Thana</label>
                            <select name="thana_id" id="thana_id" class="form-control px-3">
                                <?php $__currentLoopData = $thana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group p-1">
                            <label for="">Area</label>
                            <select name="area_id" id="area_id" class="form-control px-3">
                                <?php $__currentLoopData = $area; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group p-1">
                            <label for="">Address</label>
                            <textarea name="address"  class="form-control px-3" rows="3" placeholder="Address"></textarea>
                        </div>
                        <div class="form-group p-1 d-flex">
                            <span class="me-auto">
                                <button type="submit" class="btn btn-success ">Sign Up</button>
                            </span>
                           <span >
                            <a href="<?php echo e(route('customer.login')); ?>" class="btn btn-success "> Login</a>
                           </span>
                           
                        </div>
                    </form>
                    </div>
                  </div>
            </div>

        </div>
    </div>
</section>
<?php $__env->startPush('website-js'); ?>
<script type="text/javascript">
    //  Get Subject Javascript
    $(document).on("change","#district_id",function(){
      var district_id = $("#district_id").val();
      console.log(district_id);
        $.ajax({
          url:"<?php echo e(route('thana.change')); ?>",
          type: "GET",
          data:{district_id:district_id},
          success:function(data){
            var html = '<option value="">Select Thana </option>';
            $.each(data,function(key,v){
              html += '<option value="'+v.id+'">'+v.name+' </option>';
            });
            $("#thana_id").html(html);
          }
      });
    });
  </script>
 <script type="text/javascript">
    //  Get Subject Javascript
    $(document).on("change","#thana_id",function(){
      var thana_id = $("#thana_id").val();
      
        $.ajax({
          url:"<?php echo e(route('area.change')); ?>",
          type: "GET",
          data:{thana_id:thana_id},
          success:function(data){
            var html = '<option value="">Select Area </option>';
            $.each(data,function(key,v){
              html += '<option value="'+v.id+'">'+v.name+' </option>';
            });
            $("#area_id").html(html);
          }
      });
  
  
    });
  </script>
    
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\androidApp (8)\resources\views/website/customer/signup.blade.php ENDPATH**/ ?>