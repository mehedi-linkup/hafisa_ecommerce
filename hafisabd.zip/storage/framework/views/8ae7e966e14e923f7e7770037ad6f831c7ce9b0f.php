<footer class="bg-light mt-3 sticky-footer">
    <div class="container-fluid footer-section">
       <div class="container">
           <div class="row ">
               <div class="col-sm-6 text-left">
                   <p class="mb-0 py-2">Copyright &copy; <?php echo e($content->company_name); ?> </p>
               </div>
               <div class="col-sm-6 text-right">
                <p class="mb-0 py-2">Developed By Link Up Technology Ltd.</p> 
            </div>
           </div>
       </div>
    </div>
</footer><?php /**PATH D:\xampp\htdocs\mehedi\hafisabd\resources\views/partials/admin_footer.blade.php ENDPATH**/ ?>