<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <?php
                $prefix = Request::route()->getPrefix();
                $route = Route::current()->getName();
                ?>
            <div class="nav">
                
                <a class="nav-link  <?php echo e(($route == 'admin.index')?'active':''); ?>" href="<?php echo e(route('admin.index')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>
                <?php
                    $permisson = \App\Models\Permission::with('page')->where('user_id',Auth::id())->get();
                 ?>
                <?php $__currentLoopData = $permisson; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($p->page->name == 'order.index'): ?>
                        <?php if($p->page->status == 1): ?>
                        <a class="nav-link <?php echo e(($route == 'order.index')?'active':''); ?>"  href="<?php echo e(route('order.index')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-spinner"></i></div>
                            Pending Order
                            </a> 
                        <?php endif; ?>
                    <?php endif; ?>
                    
                    
                    <?php if($p->page->name == 'order.onProcess'): ?>
                        <?php if($p->page->status == 1): ?>
                        <a class="nav-link <?php echo e(($route == 'order.onProcess')?'active':''); ?>" href="<?php echo e(route('order.onProcess')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-project-diagram"></i></div>
                            On Processing Order
                        </a> 
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if($p->page->name == 'order.way'): ?>
                        <?php if($p->page->status == 1): ?>
                        <a class="nav-link <?php echo e(($route == 'order.way')?'active':''); ?>" href="<?php echo e(route('order.way')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-road"></i></div>
                            On The way
                        </a> 
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if($p->page->name == 'order.offer.pending'): ?>
                        <?php if($p->page->status == 1): ?>
                        <a class="nav-link <?php echo e(($route == 'order.offer.pending')?'active':''); ?>"  href="<?php echo e(route('order.offer.pending')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-spinner"></i></div>
                           Offer Pending
                            </a> 
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if($p->page->name == 'offer.onProcess'): ?>
                        <?php if($p->page->status == 1): ?>
                        <a class="nav-link <?php echo e(($route == 'offer.onProcess')?'active':''); ?>" href="<?php echo e(route('offer.onProcess')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-project-diagram"></i></div>
                            Offer On Processing Order
                        </a> 
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if($p->page->name == 'offer.way'): ?>
                        <?php if($p->page->status == 1): ?>
                        <a class="nav-link <?php echo e(($route == 'offer.way')?'active':''); ?>" href="<?php echo e(route('offer.way')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-road"></i></div>
                            Offer On The way
                        </a> 
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if($p->page->name == 'waiting.delivered'): ?>
                    <?php if($p->page->status == 1): ?>
                    <a class="nav-link <?php echo e(($route == 'waiting.delivered')?'active':''); ?>" href="<?php echo e(route('waiting.delivered')); ?>">
                        <div class="sb-nav-link-icon"><i class="fas fa-road"></i></div>
                        Waiting Delivared
                    </a> 
                    <?php endif; ?>
                     <?php endif; ?>

                    <?php if($p->page->name == 'order.delivary'): ?>
                        <?php if($p->page->status == 1): ?>
                        <a class="nav-link <?php echo e(($route == 'order.delivary')?'active':''); ?>" href="<?php echo e(route('order.delivary')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-truck-loading"></i></div>
                            Delivered Order
                        </a> 
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if($p->page->name == 'cancel.list'): ?>
                    <?php if($p->page->status == 1): ?>
                    <a class="nav-link <?php echo e(($route == 'cancel.list')?'active':''); ?>" href="<?php echo e(route('cancel.list')); ?>">
                        <div class="sb-nav-link-icon"><i class="fas fa-truck-loading"></i></div>
                        Order Cancel List
                    </a> 
                    <?php endif; ?>
                <?php endif; ?>

                    <?php if($p->page->name == 'sales.report'): ?>
                        <?php if($p->page->status == 1): ?>
                        <a class="nav-link <?php echo e(($route == 'sales.report')?'active':''); ?>" href="<?php echo e(route('sales.report')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-balance-scale-left"></i></div>
                            Sales Report
                        </a> 
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if($p->page->name == 'order.record'): ?>
                        <?php if($p->page->status == 1): ?>
                        <a class="nav-link <?php echo e(($route == 'order.record')?'active':''); ?>" href="<?php echo e(route('order.record')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-balance-scale-left"></i></div>
                            Order Record
                        </a> 
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a class="nav-link <?php echo e(($prefix == 'product')?'':'collapsed'); ?>" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts1" aria-expanded="<?php echo e(($prefix == 'product')?'true':'false'); ?>" aria-controls="collapseLayouts">
                        <div class="sb-nav-link-icon"><i class="fas fa-window-restore"></i></div>
                            Product Info
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                <div class="collapse <?php echo e(($prefix == 'product')?'collapse show':''); ?>" id="collapseLayouts1" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        
                        <?php $__currentLoopData = $permisson; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($p->page->name == 'product.create'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'product.create')?'active':''); ?>" href="<?php echo e(route('product.create')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Product Entry</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'product.index'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'product.index')?'active':''); ?>"  href="<?php echo e(route('product.index')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Product List</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'category.index'): ?>
                                <?php if($p->page->status == 1): ?>
                                <a class="nav-link <?php echo e(($route == 'category.index')?'active':''); ?>"  href="<?php echo e(route('category.index')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Category Entry</a> 
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'category.list'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'category.list')?'active':''); ?>" href="<?php echo e(route('category.list')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Category List</a>
                                <?php endif; ?>
                            <?php endif; ?>
                                <?php if($p->page->name == 'category.rank'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'category.rank')?'active':''); ?>" href="<?php echo e(route('category.rank')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Category Rank</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'subcategory.index'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'subcategory.index')?'active':''); ?>" href="<?php echo e(route('subcategory.index')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Sub Category Entry</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'subcategory.list'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'subcategory.list')?'active':''); ?>" href="<?php echo e(route('subcategory.list')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Sub Category List</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'color.index'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'color.index')?'active':''); ?>" href="<?php echo e(route('color.index')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Color </a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'size.index'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'size.index')?'active':''); ?>" href="<?php echo e(route('size.index')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Size</a>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                        
                    </nav>
                </div>
                    <a class="nav-link <?php echo e(($prefix == 'customer')?'':'collapsed'); ?>" href="<?php echo e(route('customer')); ?>" data-bs-toggle="collapse" data-bs-target="#collapseLayouts2" aria-expanded="false" aria-controls="collapseLayouts">
                        <div class="sb-nav-link-icon"><i class="fas fa-users-cog"></i></div>
                            Customer
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                <div class="collapse <?php echo e(($prefix == 'customer')?'collapse show':''); ?>" id="collapseLayouts2" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <?php $__currentLoopData = $permisson; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($p->page->name == 'customer'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'customer')?'active':''); ?>" href="<?php echo e(route('customer')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Customer Entry</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'customer.pending'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'customer.pending')?'active':''); ?>" href="<?php echo e(route('customer.pending')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Pending Customer</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'customer.list'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'customer.list')?'active':''); ?>" href="<?php echo e(route('customer.list')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Customer List</a>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </nav>
                </div>
                <a class="nav-link <?php echo e(($prefix == 'website-content')?'':'collapsed'); ?>" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts3" aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                    Website Contents
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse <?php echo e(($prefix == 'website-content')?'collapse show':''); ?> " id="collapseLayouts3" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <?php $__currentLoopData = $permisson; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($p->page->name == 'welcome'): ?>
                                <?php if($p->page->status == 1): ?>
                                <a class="nav-link <?php echo e(($route == 'welcome')?'active':''); ?>" href="<?php echo e(route('welcome')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Welcome Note</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'company.banner'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'company.banner')?'active':''); ?>" href="<?php echo e(route('company.banner')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Slider Entry</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'photo-gallery.index'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'photo-gallery.index')?'active':''); ?>" href="<?php echo e(route('photo-gallery.index')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Photo Gallery</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'video.index'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'video.index')?'active':''); ?>" href="<?php echo e(route('video.index')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Video Gallery</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'service.index'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'service.index')?'active':''); ?>" href="<?php echo e(route('service.index')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Services Entry</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'about.us'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'about.us')?'active':''); ?>" href="<?php echo e(route('about.us')); ?>"><i class="fas fa-angle-right"></i>&nbsp;About Us Page</a>
                                <?php endif; ?>
                            <?php endif; ?> 
                            <?php if($p->page->name == 'mission'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'mission')?'active':''); ?>" href="<?php echo e(route('mission')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Mission-Vission</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'managment.index'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'managment.index')?'active':''); ?>" href="<?php echo e(route('management.index')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Management Page</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'team.index'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'team.index')?'active':''); ?>" href="<?php echo e(route('team.index')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Our Team Page</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'faq'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'faq')?'active':''); ?>" href="<?php echo e(route('faq')); ?>"><i class="fas fa-angle-right"></i>&nbsp;FAQ Page</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'refund'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'refund')?'active':''); ?>" href="<?php echo e(route('refund')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Refund Policy</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'ad.index'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'ad.index')?'active':''); ?>" href="<?php echo e(route('ad.index')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Ad Management</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'management.index'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'management.index')?'active':''); ?>"  href="<?php echo e(route('management.index')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Management</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'partner.index'): ?>
                                <?php if($p->page->status == 1): ?>
                                <a class="nav-link <?php echo e(($route == 'partner.index')?'active':''); ?>" href="<?php echo e(route('partner.index')); ?>"><i class="fas fa-angle-right"></i>&nbsp; Partner</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'blog.index'): ?>
                                <?php if($p->page->status == 1): ?>
                                <a class="nav-link <?php echo e(($route == 'blog.index')?'active':''); ?>" href="<?php echo e(route('blog.index')); ?>"><i class="fas fa-angle-right"></i>&nbsp;News and Event</a>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </nav>
                </div>
                
                <?php $__currentLoopData = $permisson; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($p->page->name == 'public.sms'): ?>
                        <?php if($p->page->status == 1): ?>
                            <a class="nav-link <?php echo e(($route == 'public.sms')?'active':''); ?>  " href="<?php echo e(route('public.sms')); ?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-sms"></i></div>
                                Public Message 
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if($p->page->name == 'subscriber.list'): ?>
                        <?php if($p->page->status == 1): ?>
                            <a class="nav-link <?php echo e(($route == 'subscriber.list')?'active':''); ?> " href="<?php echo e(route('subscriber.list')); ?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-id-card-alt"></i></div>
                                Subscriber List
                            </a>
                         <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <a class="nav-link <?php echo e(($prefix == 'setting')?'':'collapsed'); ?>" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts4" aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-sliders-h"></i></div>
                    Settings
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                
                <div class="collapse <?php echo e(($prefix == 'setting')?'collapse show':''); ?> " id="collapseLayouts4" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <?php $__currentLoopData = $permisson; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($p->page->name == 'profile.edit'): ?>
                                <?php if($p->page->status == 1): ?>
                                <a class="nav-link <?php echo e(($route == 'profile.edit')?'active':''); ?>" href="<?php echo e(route('profile.edit')); ?>"><i class="fas fa-angle-right"></i>&nbsp;company profile</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'sms.sending'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'sms.sending')?'active':''); ?>" href="<?php echo e(route('sms.sending')); ?>"><i class="fas fa-angle-right"></i>&nbsp;SMS Sending</a>
                                <?php endif; ?>
                            <?php endif; ?>
                                <?php if($p->page->name == 'admin.phone.edit'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'admin.phone.edit')?'active':''); ?>" href="<?php echo e(route('admin.phone.edit')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Admin Phone Edit</a>
                                <?php endif; ?>
                             <?php endif; ?>
                            <?php if($p->page->name == 'page.list'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'page.list')?'active':''); ?>" href="<?php echo e(route('page.list')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Page List</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'area.index'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'area.index')?'active':''); ?>" href="<?php echo e(route('area.index')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Area Entry</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'thana.index'): ?>
                            <?php if($p->page->status == 1): ?>
                                <a class="nav-link <?php echo e(($route == 'thana.index')?'active':''); ?>" href="<?php echo e(route('thana.index')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Thana Entry</a>
                            <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'country.index'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'country.index')?'active':''); ?>" style="white-space: nowrap" href="<?php echo e(route('country.index')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Country Management</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'user.index'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'user.index')?'active':''); ?>"  href="<?php echo e(route('user.index')); ?>"><i class="fas fa-angle-right"></i>&nbsp;User Create</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'permission.index'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'permission.index')?'active':''); ?>"  href="<?php echo e(route('permission.index')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Permission</a>
                                <?php endif; ?>
                            <?php endif; ?>
                             <?php if($p->page->name == 'customer.offer'): ?>
                                <?php if($p->page->status == 1): ?>
                                    <a class="nav-link <?php echo e(($route == 'customer.offer')?'active':''); ?>"  href="<?php echo e(route('customer.offer')); ?>"><i class="fas fa-angle-right"></i>&nbsp;Offer Settings</a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($p->page->name == 'user.phone.edit'): ?>
                            <?php if($p->page->status == 1): ?>
                                <a class="nav-link <?php echo e(($route == 'user.phone.edit')?'active':''); ?>"  href="<?php echo e(route('user.phone.edit')); ?>"><i class="fas fa-angle-right"></i>&nbsp;User Phone Settings</a>
                            <?php endif; ?>
                        <?php endif; ?>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <a class="nav-link <?php echo e(($route == 'set-time')?'active':''); ?>" href="<?php echo e(route('set-time')); ?>"><i class="fas fa-angle-right"></i>&nbsp; Time Set</a>
                       
                    </nav>
                </div>
                <a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="return confirm('Are you sure logout from Admin Panel')">
                    <div class="sb-nav-link-icon"><i class="fas fa-sign-out-alt"></i></div>
                    Log Out
                </a>
            </div>
        </div>
    </nav>
</div><?php /**PATH /home/dewbxcak/zeneviaexpress.com/resources/views/partials/admin_sidebar.blade.php ENDPATH**/ ?>