
<?php $__env->startSection('website-css'); ?>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('website-content'); ?>

<section class="py-3 middle-section">
    <h2 class="text-center text-success"> Checkout</h2>
    <div class="container">
        <?php if(Auth::guard('customer')->user()->status == 'a' && Auth::guard('customer')->user()->isVerified == '1' ): ?>
        <form action="<?php echo e(route('orderStore')); ?>" method="post">
            <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-6 col-12">
                <div class="card py-3 px-2">
                    <div class="card-body p-2">
                        <h5 class="px-3">Billing Address</h5>
                          
                          <div class="form-group px-3 py-1 d-flex">
                            <label for="" class="p-1 w-50" >Name<span class="text-danger ">*</span></label>
                            <input type="text" name="customer_name" class="form-control px-2 c-field" value="<?php echo e(Auth::guard('customer')->user()->name); ?>" placeholder="Enter Name *" required>
                        </div>
                        <div class="form-group px-3 py-1 d-flex">
                            <label for="" class="pb-1 w-50">Phone<span class="text-danger">*</span></label>
                            <input type="text" name="customer_mobile" value="<?php echo e(Auth::guard('customer')->user()->phone); ?>" class="form-control px-3 c-field" placeholder="Enter Phone Number *"  required>
                        </div>
                        <div class="form-group px-3 py-1 d-flex">
                            <label for="" class="pb-1 w-50">Email</label>
                            <input type="email" name="customer_email" value="<?php echo e(Auth::guard('customer')->user()->email); ?>" class="form-control px-3 c-field" placeholder="Enter Email" >
                        </div>

                        <div class="form-group px-3 py-1 d-flex">
                            <label for="" class="pb-1 w-50">District<span class="text-danger">*</span></label>
                            <select  id="district_id" class="form-control c-field"  required>
                                <option value="">Select District </option>
                                    <?php $__currentLoopData = $district; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group px-3 py-1 d-flex">
                            <label for="" class="pb-1 w-50">Thana<span class="text-danger">*</span></label>
                            <select  name="thana_id" id="thana_id" class="form-control c-field" required >
                            </select>
                        </div>
                        <div class="form-group px-3 py-1 d-flex">
                            <label for="" class="pb-1 w-50">Area<span class="text-danger">*</span></label>
                            <select  name="area_id" id="area_id" class="form-control c-field" required >
                                
                            </select>
                        </div>
                        <div class="form-group px-3 py-1 d-flex">
                            <label for="" class="pb-1 w-50">Delivery Date<span class="text-danger">*</span></label>
                            <input type="text" name="delivery_date" id="date" onchange="datechange()"  class="form-control c-field" placeholder="Delivery Date *" required>
   
                        </div>
                        <div class="form-group px-3 py-1 d-flex">
                            <label for="" class="pb-1 w-50">Select Time<span class="text-danger">*</span></label>
                            <select name="time_id" id="time_id" class=" form-control c-field"  required>
                                
                            </select>
                        </div>
                        <div class="form-group px-3 py-1 d-flex">
                            <label for="" class="pb-1 w-50 ">Billing Address</label>
                            <input type="text" name="billing_address" value="<?php echo e(Auth::guard('customer')->user()->address); ?>" class="form-control c-field" placeholder="Billing address *"  required>
                        </div>
                        <div class="form-group px-3 py-1 d-flex">
                            <label for="" class="pb-1 w-50">Shipping Address<span class="text-danger">*</span></label>
                            <input type="text" name="shipping_address"  class="form-control c-field" placeholder="Billing address *" placeholder="Shipping Address">
                        </div>
                        <div class="form-group px-3 py-1 d-flex">
                            <label for="" class="pb-1 w-50">Note</label></label>
                            <textarea name="order_note"  class="form-control px-3" rows="3" placeholder="Note"></textarea>
                        </div>
                    </div>
                  </div>
            </div>
            <div class="col-lg-6 col-12">
                <div class="card p-3">
                    <div class="card-body p-2">
                        <h5 class="text-start">Order Summery </h5>
                        <table class="table table-bordered px-3">
                            <thead>
                                <tr>
                                    <td>Products</td>
                                    <td class="text-center">Quantity</td>
                                    <td class="text-end">Total</td>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <?php $__currentLoopData = \Cart::getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($cart->quantity - $cart->attributes->quantity>0): ?>
                                        <tr>
                                            <td><?php echo e($cart->name); ?></td>
                                            <td class="text-center" ><?php echo e($cart->quantity - $cart->attributes->quantity); ?></td>
                                             <td class="text-end"><?php echo e($cart->attributes->sum ? $cart->attributes->sum - $cart->attributes->offer_price : $cart->price); ?> TK</td>
                                        </tr> 
                                        <?php endif; ?>
                                        <?php if($cart->attributes->quantity>0): ?>
                                            <tr class="text-success">
                                                <td><?php echo e($cart->name); ?> <span class="fw-bolder">(Offer Product)</span></td>
                                                <td class="text-center" ><?php echo e($cart->attributes->quantity); ?></td>
                                                <td class="text-end"><?php echo e($cart->attributes->offer_price ? $cart->attributes->offer_price : $cart->price); ?> TK</td>
                                            </tr>
                                        <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr >
                                    <td colspan="2">Shipping Charge</td>
                                    
                                    <td class="text-end shipping_charge"></td>
                                </tr>
                                <tr>
                                    <td colspan="2">Total Amount</td>
                                    <?php
                                    //  $total = array_sum($item->price);
                                    ?>
                                    <input type="hidden" name="total amount" value="<?php echo e($sum); ?>">
                                    <td class="text-end"> <?php echo e($sum); ?> + <span class="shipping_charge"></span> <span>Tk</span> </td>
                                </tr>
                            </tbody>
                        </table>
                        
                    </form>
                        <div class="">
                            <span><a href="<?php echo e(route('home')); ?>" class="btn btn-success border-0 rounded-0">Continue Shipping</a></span>
                            <?php if($sum >= $offer->minimum_order_amount): ?>
                            <span><button class="btn btn-danger border-0 rounded-0" type="submit">Place Order</button></span>
                            <?php else: ?> 
                                <p class="pt-3"><span class="text-danger">Note</span> Please Minimum Order Amount <?php echo e($offer->minimum_order_amount); ?> TK</p>
                            <?php endif; ?>
                        </div>
                    </div>
                  </div>
            </div>
        </div>
    </form>
        <?php elseif(Auth::guard('customer')->user()->isVerified != '1' ): ?>
        <h4 class="text-center text-danger"> Your Account no verified</h4>
        <div class="text-center"><a href="<?php echo e(route('customer.resend.otp')); ?>" class="text-center">Please send otp to <?php echo e(Auth::guard('customer')->user()->phone); ?> </a></div>
        <?php else: ?> 
         <h4 class="text-center text-danger">Your Account Inactive. Please contact Admin</h4>
            
        <?php endif; ?>
       
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php $__env->startPush('website-js'); ?>
<script type="text/javascript">
    //  Get Subject Javascript
    $(document).on("change","#district_id",function(){
      var district_id = $("#district_id").val();
      console.log(district_id);
        $.ajax({
            url:"<?php echo e(route('thana.change')); ?>",
          type: "GET",
          data:{district_id:district_id},
          success:function(data){
            var html = '<option value=""> Select Thana </option>';
            $.each(data,function(key,v){
              html += '<option value="'+v.id+'">'+v.name+' </option>';
            });
            $("#thana_id").html(html);
          }
      });
  
  
    });
  </script>

<script type="text/javascript">
    //  Get Subject Javascript
    $(document).on("change","#district_id",function(){
      var district_id = $("#district_id").val();
      console.log(district_id);
        $.ajax({
          url:"<?php echo e(route('thana.change')); ?>",
          type: "GET",
          data:{district_id:district_id},
          success:function(data){
            var html = '<option value="">Select Thana </option>';
            $.each(data,function(key,v){
              html += '<option value="'+v.id+'">'+v.name+' </option>';
            });
            $("#thana_id").html(html);
          }
      });
    });
  </script>
 <script type="text/javascript">
    //  Get Subject Javascript
    $(document).on("change","#thana_id",function(){
      var thana_id = $("#thana_id").val();
      
        $.ajax({
          url:"<?php echo e(route('area.change')); ?>",
          type: "GET",
          data:{thana_id:thana_id},
          success:function(data){
            var html = '<option value="">Select Area </option>';
            $.each(data,function(key,v){
              html += '<option value="'+v.id+'">'+v.name+' </option>';
            });
            $("#area_id").html(html);
          }
      });
  
  
    });
  </script>

 <script>
    $(function() {
     var date = new Date();
     var dayNo = date.getDay();
     var mindate = (7 - dayNo);
     var d = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday' ];
        
     $("#date").datepicker({
       dateFormat: 'dd-mm-yy /DD',
       onSelect: function(dateText, inst) {
         var today = new Date(dateText);
        var day = d[today.getDay()];
         console.log(d[dateText]);
         var input_day = $('#date').val();
         var day_pass = $(this).datepicker('getDate').toString();
         var day_pass = day_pass.substring(0, 3);
        //  console.log(day_pass);
         console.log(day_pass.substring(0, 3));
        $.ajax({
               url:"<?php echo e(route('time.show')); ?>",
                   type:"get",
                   data:{"day_pass" : day_pass},
                   dataType: "json",
                   success:function(res){
                       console.log(res);
                       var html = '<option value="">Select Time </option>';
                       $.each(res,function(key,v){
                       html += '<option value="'+v.id+'">'+v.time+' </option>';
                       });
                       $("#time_id").html(html);
                   }
              })
       }
   
     });
    
         
   });
    </script>
    <script>

    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\androidApp (6)\resources\views/website/customer/checkout.blade.php ENDPATH**/ ?>