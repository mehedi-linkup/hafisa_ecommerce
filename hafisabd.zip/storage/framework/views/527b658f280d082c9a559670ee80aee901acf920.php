
<?php $__env->startSection('title', 'Page Active'); ?>
<?php $__env->startSection('admin-content'); ?>
<main>
   <div class="container ">
    <div class="heading-title p-2 my-2">
        <span class="my-3 heading "><i class="fas fa-home"></i> <a class="" href="<?php echo e(route('admin.index')); ?>">Home</a> >Area</span>
    </div>
          <div class="row">
              <div class="col-md-12">
                  <div class="card"> 
                      <div class="card-header">
                          <div class="table-head"><i class="fas fa-table me-1"></i>Page List <a href="" class="float-right"><i class="fas fa-print"></i></a></div>
                      </div>
                      <div class="card-body table-card-body p-3">
                          <table id="datatablesSimple"  class="text-center table-striped" width="100%">
                              <thead class="bg-light">
                                  <tr class="">
                                      <th width="10%">SL</th>
                                      <th width="70%">Name</th>
                                      <th width="20%" class="text-center">Action</th>
                                  </tr>
                              </thead>
                              <tbody>
                                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($page->display_name); ?></td>
                                    <td class="text-center text-nowrap">
                                      <form action="<?php echo e(route('page.active')); ?>" class="" method="post">
                                          <?php echo csrf_field(); ?>
                                          <input type="hidden" name="id" value="<?php echo e($page->id); ?>">
                                          <?php if($page->status == 1): ?>
                                              <button type="submit" class="btn btn-edit">Active</button>
                                              <?php else: ?>
                                              <button type="submit" class="btn btn-delete">Deactive</button>
                                          <?php endif; ?>
                                      </form>
                                    </td>
                                  </tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                          </table>
                      </div>
                  </div>
              </div>
          </div>
    </div>
</main>        
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin-js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Zenevia-update\resources\views/admin/pages/index.blade.php ENDPATH**/ ?>