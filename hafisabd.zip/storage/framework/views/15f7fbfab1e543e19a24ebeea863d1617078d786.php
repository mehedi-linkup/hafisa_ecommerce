

<?php $__env->startSection('website-content'); ?>

<section class="py-3">
    <div class="container">
        <nav style="--bs-breadcrumb-divider: '';" aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page"></li>
            </ol>
          </nav>
    </div>
</section>
<section>
    <?php $__currentLoopData = $Categorylist->SubCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="container">
        <div class="feature-h3 ">
            <h3><?php echo e($Categorylist->name); ?></h3>
        </div>
        <div class="row py-3">
            <?php $__currentLoopData = $Categorylist->SubCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-6 col-12 mb-2">
                    <a href="<?php echo e(route('SubCategoryWise.list',$item->slug)); ?>" class="row border">
                    
                        <div class="col-lg-7 col-md-6 col-6">
                            <div class="category-title  py-3">
                                <p class=" text-center mb-0"><?php echo e($item->name); ?></p>
                            </div>
                        </div>
                        <div class="col-lg-5 col-md-6 col-6 text-center">
                            <div class="category-img py-2">
                                <img src="<?php echo e(asset($item->image)); ?>" alt="">
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\hafisabd\resources\views/website/subcategory_list.blade.php ENDPATH**/ ?>