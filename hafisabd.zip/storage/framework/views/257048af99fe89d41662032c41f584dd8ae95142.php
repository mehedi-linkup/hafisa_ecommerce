<section class="footer-top py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-6">
                <div class="footer-logo d-flex align-items-center">
                    <a style="display: inline-block;width:100px;" href="<?php echo e(route('home')); ?>"><img style="width: 100%" src="<?php echo e(asset('/')); ?><?php echo e($content->logo); ?>" alt=""></a>
                    <span style="color:#fff;display:inline-block"><?php echo e($content->company_name); ?></span>
                </div>
                <div style="font-size:12px;color:#fff;margin-top:10px"><?php echo Str::of($content->about_description)->words(25); ?></div>
            </div>
            <div class="col-lg-3 col-md-3 col-6">
                <h1 class="fs-6 text-white">Information Link</h1>
                <ul class="information">
                    <li><a href="<?php echo e(route('about.website')); ?>">About Us</a></li>
                    <li><a href="<?php echo e(route('web.contact')); ?>">Contact Us</a></li>
                    <li><a href="<?php echo e(route('about.website')); ?>#management">Our Management</a></li>
                    <li><a href="<?php echo e(route('about.website')); ?>#mission">Our Mission and Vision</a></li>
                    
                </ul>
            </div>
            <div class="col-lg-3 col-md-3 col-6">
                <h1 class="fs-6 text-white">Social Link</h1>
                <ul class="information">
                    <li><a href="<?php echo e($content->facebook); ?>" target="_blank">Facebook</a></li>
                    <li><a href="<?php echo e($content->twitter); ?>"  target="_blank">Twitter</a></li>
                    <li><a href="<?php echo e($content->instagram); ?>"  target="_blank">Instagram</a></li>
                    <li><a href="<?php echo e($content->linkedin); ?>"  target="_blank">Linkedin</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-3 col-6">
                <h1 class="fs-6 text-white">Address</h1>
                <ul class="information">
                    <li><a href="tel:<?php echo e($content->phone_1); ?>">Phone 1: <?php echo e($content->phone_1); ?></a></li>
                    <?php if($content->phone_2): ?>
                    <li><a href="tel:<?php echo e($content->phone_1); ?>">Phone 2: <?php echo e($content->phone_2); ?></a></li>
                    <?php endif; ?>
                   
                    <li><a href="mailto:<?php echo e($content->email); ?>">Email : <?php echo e($content->email); ?></a></li>
                    <li><a href="javascript:void(0)">Address :<?php echo e($content->address); ?></a></li>
                </ul>
            </div>
        </div>
    </div>
</section>
<div class="live-chat">
    <a href="<?php echo e(route('web.contact')); ?>"><i class="fas fa-comment-dots"></i></a>
</div>
<section class="footer-bottom">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-md-6">
                <!--<div class="all-right py-2">All Rights Researved © Zenevia Express shop</div>-->
            </div>
            <div class="col-lg-6 col-md-6 col-md-6 d-flex justify-content-end">
                <div class="develop py-1">
                    <small>Design And Develop By <a href="http://linktechbd.com/">Link-up
                        Technology</a></small> </div>
            </div>
        </div>
    </div>
</section>
<!-- End Footer Section -->
</div><?php /**PATH D:\xampp\htdocs\mehedi\hafisabd\resources\views/partials/website_footer.blade.php ENDPATH**/ ?>