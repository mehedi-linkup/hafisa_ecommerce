<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>
        
        <meta name="author" content="MD Sazzat Hossain" />
        <title><?php echo e($content->company_name); ?> | <?php echo $__env->yieldContent('title'); ?></title>
        
        <link href="<?php echo e(asset('admin/css/select2.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('admin/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('admin/css/dataTabel.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('admin/css/styles.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('admin/css/custom.css')); ?>" rel="stylesheet" />
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/css/invoice.css')); ?>">
        <?php echo $__env->yieldPushContent('admin-css'); ?>
    </head>
    <body class="sb-nav-fixed fixed-footer"  onload="startTime()">
        <?php echo $__env->make('partials.admin_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">  
        
            <?php echo $__env->make('partials.admin_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                 <div class="container mt-4">
                     <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                    <?php endif; ?>

                    <?php if($message = Session::get('error')): ?>
                    <div class="alert alert-danger alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                    <?php endif; ?>

                    <?php if($message = Session::get('warning')): ?>
                    <div class="alert alert-warning alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                    <?php endif; ?>

                    <?php if($message = Session::get('info')): ?>
                    <div class="alert alert-info alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                    <?php endif; ?>
                    <?php if($message = Session::get('delete_check')): ?>
                    <div class="alert alert-info alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                    <?php endif; ?>

                    <?php if($message = Session::get('delete')): ?>
                    <div class="alert alert-danger alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                    <?php endif; ?>

                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        Check the following errors :(
                    </div>
                    <?php endif; ?> 
                    
                <?php echo $__env->yieldContent('admin-content'); ?> 
                <?php echo $__env->make('partials.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <script src="<?php echo e(asset('admin/js/jquery-3.6.0.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/js/scripts.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/js/simple-datatables@latest.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/js/datatables-simple-demo.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/js/select2.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/js/all.min.js')); ?>"></script>
        <script>
            function startTime() {
              const today = new Date();
              const days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
              const months = ["January","February","March","April","May","June","July","August","September","October","November","December"];
              let d = today.getDay();
              let date = today.getDay();
              let h = today.getHours();
              let m = today.getMinutes();
              let s = today.getSeconds();
              m = checkTime(m);
              s = checkTime(s);
              document.getElementById('txt').innerHTML =days[today.getDay()]+','+' '+today.getDate()+' '+months[today.getMonth()]+' '+today.getFullYear()+','+' '+h + ":" + m + ":" + s;
              setTimeout(startTime, 1000);
            }
            function checkTime(i) {
              if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
              return i;
            }
            </script>
        <script>
            $("document").ready(function(){
              setTimeout(function(){
              $("div.alert").fadeOut();
              }, 3000 ); // 5 secs

              $('.js-example-basic-multiple').select2();
          });
      </script>
     
      <script>
          window.addEventListener('DOMContentLoaded', event => {
          // Simple-DataTables
          // https://github.com/fiduswriter/Simple-DataTables/wiki
      
          const datatablesSimple = document.getElementById('first_table');
          if (datatablesSimple) {
              new simpleDatatables.DataTable(datatablesSimple);
          }
          const confirmTable = document.getElementById('confirm');
          if (confirmTable) {
              new simpleDatatables.DataTable(confirmTable);
          }
          });
      </script>
        <?php echo $__env->yieldPushContent('admin-js'); ?>
    </body>
</html>
<?php /**PATH D:\xampp\htdocs\androidApp (8)\resources\views/layouts/admin.blade.php ENDPATH**/ ?>