
<?php $__env->startSection('title', 'Create User'); ?>
<?php $__env->startSection('admin-content'); ?>
<main>
   <div class="container ">
    <div class="heading-title p-2 my-2">
        <span class="my-3 heading "><i class="fas fa-home"></i> <a class="" href="<?php echo e(route('admin.index')); ?>">Home</a> > <a href="<?php echo e(route('user.index')); ?>"> user </a> > Update Password</span>
    </div>
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card m-b-20">
                <div class="card-body">
                    <form action="<?php echo e(route('password.update')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="col-12 mx-auto mb-3">
                            <label for="current-pwd" class="required">Current Password</label>
                            <input type="password" class="form-control <?php $__errorArgs = ['currentPass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="currentPass" id="current-pwd" placeholder="Current Password" />
                            <?php $__errorArgs = ['currentPass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <?php echo e($message); ?>      
                                </span>  
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      
                            <div class="col-lg-12 mb-3">
                                <label for="new-pwd" class="required">New Password</label>
                                <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" id="new-pwd" placeholder="New Password" />
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <?php echo e($message); ?>      
                                </span>  
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <div class="single-input-item">
                                    <label for="confirm-pwd" class="required">Confirm Password</label>
                                    <input type="password"  class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password_confirmation" id="confirm-pwd" placeholder="Confirm Password" />
                                </div>
                            </div>
                      
                        <div class="single-input-item col-lg-12">
                            <button class="btn btn-danger btn-sm" type="submit">Change Password</button>
                        </div> 
                    </form>
                    
                </div>
            </div>
         </div> <!-- end col -->
            
        </div>
    </div>
    
</main>        
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin-js'); ?>

    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dewbxcak/zeneviaexpress.com/resources/views/auth/password_change.blade.php ENDPATH**/ ?>